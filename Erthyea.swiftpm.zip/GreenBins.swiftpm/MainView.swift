//import SwiftUI
//
//struct DragAndDropPage: View {
//    @State private var imageOffset: CGSize = .zero
//    @State private var score: Int = 0
//    @State private var showImage: Bool = true
//    @State private var negativeScore: Int = 0  // Added state to track negative score
//
//    //let imageNames: [String] = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]
//    //@State var chosenName = ["1"]
//    var body: some View {
//        ZStack{
//            Color.black.ignoresSafeArea(.all)
//            VStack{
//                HStack {
//                    // Blue Bar on the Left
//                    Rectangle()
//                        .fill(Color.blue)
//                        .frame(width: 15)
//
//                    Spacer()
//
//                    // Green Bar on the Right
//                    Spacer()
//
//                    Rectangle()
//                        .fill(Color.green)
//                        .frame(width: 15)
//
//                    //Spacer(minLength: 40)
//                }
//                // Yellow Bar at the Bottom
//                Rectangle()
//                    .fill(Color.yellow)
//                    .frame(height: 15)
//            }
//            Spacer()
//            VStack {
//                if showImage {
//                    
//                    
//                    ForEach(1..<10){ imName in
//                        let imageName = String(imName)
//                                Image(imageName)
//                                    .resizable()
//                                    .aspectRatio(contentMode: .fit)
//                                    .frame(width: 50, height: 50)
//                                    .cornerRadius(10)
//                                    .position(randomImagePosition())
//                                    .offset(imageOffset)
//                                    .gesture(
//                                        DragGesture()
//                                            .onChanged { gesture in
//                                                self.imageOffset = CGSize(width: gesture.translation.width, height: gesture.translation.height)
//                                            }
//                                            .onEnded { gesture in
//                                                if imageName == "1" || imageName == "2" || imageName == "3"{
//                                                    if gesture.translation.width > 0 {// Dragged to the right
//                                                        updateScore()
//                                                    }else{
//                                                        updateNegativeScore()
//                                                    }
//                                                }else if imageName == "4" || imageName == "5" || imageName == "6"{
//                                                    if gesture.translation.width < 0 {// Dragged to the right
//                                                        updateScore()
//                                                    }else{
//                                                        updateNegativeScore()
//                                                    }
//                                                }else if imageName == "7" || imageName == "8" || imageName == "9"{
//                                                    if gesture.translation.width > 0 || gesture.translation.width < 0{// Dragged to the right
//                                                        updateNegativeScore()
//                                                    }else{
//                                                        updateScore()
//                                                    }
//                                                }
//                                                self.showImage = false
//                                                
//                                                //if let index = imageNames.firstIndex(of: imageName), index + 1 < imageNames.count {
//    //                                                self.chosenName = [imageNames[index + 1]]
//    //                                            }
//                                            }
//                                    )
//                                    .onAppear {
//                                        self.startFallingAnimation(for: imageName)
//                                    }
//                                    .onTapGesture {
//                                        self.showImage = false
//                                    }
//                            }
//                    
//                            
//                         }
//                    }
//                        //else {
////                        Text("Final Score")
////                            .font(.largeTitle)
////                        Text("\(score - negativeScore)")
////                            .font(.largeTitle)
////                        Button(action: {
////                            // Add your play button action here
////                            //CirclePage()
////                            
////                        }) {
////                                Text("Home")
////                                    .font(.title)
////                                    .padding()
////                                    .foregroundColor(.white)
////                                    .background(Color.gray)
////                                    .cornerRadius(10)
////                            
////                        }
////                    }
//            //}
//            
//            
//            Spacer()
//            Text("Score: \(max(0, score - negativeScore))")  // Display user's score after considering negative score
//            Spacer()
//        }
//    }
//    
//    private func updateScore(){
//        self.score += 4
//    }
//    private func updateNegativeScore(){
//        self.negativeScore += 2
//    }
//    
//    private func randomImagePosition() -> CGPoint {
//        let x = CGFloat.random(in: 0...(UIScreen.main.bounds.width - 50))
//        return CGPoint(x: x, y: -50) // Start the images above the screen
//    }
//    
//    private func startFallingAnimation(for imageName: String) {
//        DispatchQueue.main.asyncAfter(deadline: .now() + Double.random(in: 0.1...0.9)) {
//            withAnimation(Animation.linear(duration: 10)) {
//                self.imageOffset.height = UIScreen.main.bounds.height - 100
//            }
//        }
//    }
//}
//

import SwiftUI

struct DragAndDropPage: View {
    @State private var score: Int = 0
    @State private var showImage: Bool = true
    @State private var negativeScore: Int = 0  // Added state to track negative score
    @State private var imageNameIndex: Int = 0

    let imageNames: [String] = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea(.all)
            
            VStack {
                HStack {
                    // Blue Bar on the Left
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: 15)
                    
                    Spacer()
                    
                    // Green Bar on the Right
                    Spacer()
                    
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: 15)
                }
                // Yellow Bar at the Bottom
                Rectangle()
                    .fill(Color.yellow)
                    .frame(height: 15)
            }
            
            VStack {
                if showImage {
                    Image(imageNames[imageNameIndex])
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .cornerRadius(10)
                        .position(CGPoint(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 2))
                        .gesture(
                            DragGesture()
                                .onEnded { gesture in
                                    handleDragEnd(gesture)
                                }
                        )
                        .onTapGesture {
                            self.showImage = false
                        }
                }
            }
            Spacer()
            
            Spacer()
            Text("Score: \(max(0, score - negativeScore))")
            Spacer()
        }
    }
    
    private func handleDragEnd(_ gesture: DragGesture.Value) {
        let imageName = imageNames[imageNameIndex]
        
        switch imageName {
        case "1", "2", "3":
            updateScore(gesture.translation.width > 0, 1)
        case "4", "5", "6":
            updateScore(gesture.translation.width < 0, 2)
        case "7", "8", "9":
            if(gesture.translation.width > 0 || gesture.translation.width < 0){
                updateScoreYellow(true, 0)
            }else{
                updateScoreYellow(true, 3)
            }
        default:
            break
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + Double.random(in: 1.0...2.0)) {
                    imageNameIndex += 1
                    showImage = imageNameIndex < imageNames.count
                }
    }
    
    private func updateScore(_ isPositive: Bool, _ num: Int) {
        if (isPositive && (num == 1 || num == 2 || num == 3)){
            score += 4
        } else {
            negativeScore += 2
        }
    }
    private func updateScoreYellow(_ isPositive: Bool, _ num: Int) {
        if (isPositive && num == 3){
            negativeScore += 2
        } else {
            score += 4
        }
    }
}
