import SwiftUI

struct EndGameView: View{
    var body: some View{
        NavigationView{
            VStack{
                
                Text("Well Done!!")
                    .font(.largeTitle)
                    .padding(.top , 350)
                Button(action: {
                    // Add your play button action here
                    
                    
                }) {
                    NavigationLink(destination: GreenBinView()){
                        Text("Play Again")
                            .font(.title)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.gray)
                            .cornerRadius(10)
                    }
                }
                Text("Highest Score: 0")
                    .font(.largeTitle)
                    .padding(.top , 50)
                Spacer()
            }
        }
    }
}
