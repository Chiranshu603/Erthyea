import SwiftUI

//struct ContentView: View {
//    var body: some View {
//        ZStack{
//            Color.black.ignoresSafeArea(.all)
//            TabView {
//                // First Tab: Circle Page
//                CirclePage()
//                    .tabItem {
//                        Image(systemName: "house.fill")
//                            .resizable()
//                            .frame(width:100 , height: 100)
//                        Text("HOME")
//                    }
//                
//                // Second Tab: Another Page (Replace this with your desired content)
//                ScoreBoard()
//                    .tabItem {
//                        Image(systemName: "pencil.and.list.clipboard.rtl")
//                            .resizable()
//                            .frame(width: 100,height: 100)
//                        Text("SCORE")
//                    }
//            }
//        }
//    }
//}



struct CirclePage: View {
    var body: some View {
        NavigationView{
        ZStack {
            
            Color.black.ignoresSafeArea(.all)
         
                VStack {
                    HStack {
                        // First Circle with Image
                        
                            Button(action: {
                                //self.circleTapped(image: "image1")
                            }) {
                                NavigationLink(destination: GreenBinView()){
                                    CircleImageView(imageName: "image1", circleColor: .green)
                                        .padding(.top , 50)
                                }
                            }
                        
                        
                        
                        // Second Circle with Image
                        Button(action: {
                            //self.circleTapped(image: "image2")
                        }) {
                            NavigationLink(destination: YellowBinView()){
                                CircleImageView(imageName: "image2", circleColor: .yellow)
                                    .padding(.top , 50)
                            }
                        }
                        
                    }
                    // Third Circle with Image
                    Button(action: {
                        //self.circleTapped(image: "image3")
                    }) {
                        NavigationLink(destination: BlueBinView()){
                            CircleImageView(imageName: "image3", circleColor: .blue)
                                .padding(.top , 50)
                        }
                        
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        // Add your play button action here
                        
                        
                    }) {
                        NavigationLink(destination: DragAndDropPage()){
                            Text("Play")
                                .font(.title)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.gray)
                                .cornerRadius(10)
                        }
                    }
                    Text("Highest Score: 0")
                        
                    Spacer()
                }
            }
        }
        .foregroundColor(.white)
    }

}

struct CircleImageView: View {
    var imageName: String
    var circleColor: Color
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 150, height: 150)
                //.frame(width: 350,height: 400)
                //.clipShape(Circle())
                //.shadow(radius: 7)
        }
        .background(circleColor)
        //.clipShape(Circle())
        .padding()
    }
}

//struct ScoreBoard: View{
//    var body: some View{
//        ZStack{
//            
//            VStack{
//                Text("SCORE BOARD")
//    //            ZStack{
//    //                Text(score)
//    //                    .font(.title)
//    //                    .padding()
//    //                    .foregroundColor(.white)
//    //                    .background(Color.gray)
//    //                    .cornerRadius(10)
//    //            }
//            }
//        }
//        
//    }
//}

    

