//
//  BlueBinView.swift
//  GreenBins
//
//  Created by student on 23/02/24.
//

import Foundation
import SwiftUI

struct BlueBinView: View{
    var body: some View{
        VStack{
            Color.black.ignoresSafeArea(.all)
            ImageAndScrollPageBlue(centerImage: "image3")
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Images")
                }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10){
                    VStack{
                        SmallSquareBoxBlueView(imageName: "4")
                        Text("Plastic Bottles")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 10)
                            .frame(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        //                    .padding(.leading, 20)
                    }
                    
                    VStack{
                        SmallSquareBoxBlueView(imageName: "5")
                        Text("Used Paper")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 20)
                    }
                    VStack{
                        SmallSquareBoxBlueView(imageName: "6")
                        Text("Broken Glass")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.leading , 20)
                    }
                }
            }
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .background {
                Color.black.opacity(1.0)
                    .ignoresSafeArea()
            }
    }
}

struct ImageAndScrollPageBlue: View {
    var centerImage: String
    
    var body: some View {
        VStack {
            //Spacer()
            // Image in the Center
            CenteredImageBlueView(imageName: centerImage)
                //.padding(.top, 16.16)
                .frame(width: 200, height: 200)
            Text("BLUE BIN")
                .font(.largeTitle)
                .padding(.top , 110)
                .padding(.bottom, 30)
            Spacer()
            // Horizontal Scroll View with Square Boxes
 //           ScrollView(.horizontal, showsIndicators: false) {
//                HStack(spacing: 20) {
//                    ForEach(4..<7) { index in
//                        SmallSquareBoxBlueView(imageName: "\(index)")
//                    }
//                }
                
                //.padding()
            }
            
        }
    
}


struct CenteredImageBlueView: View {
    var imageName: String
    
    var body: some View {
        Image(imageName)
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 250)
    }
}

struct SmallSquareBoxBlueView: View {
    var imageName: String
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
                .cornerRadius(10)
        }
        .background(Color.black)
        .cornerRadius(10)
    }
}
