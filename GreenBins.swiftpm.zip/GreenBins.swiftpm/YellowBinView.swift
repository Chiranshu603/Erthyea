import SwiftUI

struct YellowBinView: View {
    var body: some View {
        VStack{
            Color.black.ignoresSafeArea(.all)
            ImageAndScrollPage(centerImage: "image2")
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Images")
                }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20){
                    VStack(spacing: -30) {
                        SmallSquareBoxView(imageName: "7")
                        Text("Old Batteries")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 30)
                            .padding(.leading, 20)
                    }
                    
                    VStack(spacing: -30){
                        SmallSquareBoxView(imageName: "8")
                        Text("Broken Bulb")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 10)
                    }
                    VStack(spacing: -25){
                        SmallSquareBoxView(imageName: "9")
                        Text("Used Can")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.leading, 5)
                    }
                }
            }
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .background {
                Color.black.opacity(1.0)
                    .ignoresSafeArea()
            }
    }
}

struct ImageAndScrollPage: View {
    var centerImage: String
    
    var body: some View {
        VStack {
            
            // Image in the Center
            CenteredImageView(imageName: centerImage)
                .frame(width: 200, height: 200)
         
            Text("YELLOW BIN")
                .font(.largeTitle)
                .padding(.top , 110)
                .padding(.bottom, 30)
            // Horizontal Scroll View with Square Boxes
//            ScrollView(.horizontal, showsIndicators: false) {
//                HStack(spacing: 20) {
//                    ForEach(7..<10) { index in
//                        SmallSquareBoxView(imageName: "\(index)")
//                    }
//                }
//                .padding()
//            }
            
        }
    }
}

struct CenteredImageView: View {
    var imageName: String
    
    var body: some View {
        Image(imageName)
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 230)
            //.padding(.top , -20)
    }
}

struct SmallSquareBoxView: View {
    var imageName: String
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 200)
                .cornerRadius(10)
        }
        .background(Color.black)
        .cornerRadius(10)
    }
}
