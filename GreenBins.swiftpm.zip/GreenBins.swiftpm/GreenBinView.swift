import SwiftUI

struct GreenBinView: View {
    var body: some View {
        VStack{
            Color.black.ignoresSafeArea(.all)
            ImageAndScrollPageGreen(centerImage: "image1")
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Images")
                }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20){
                    VStack{
                        SmallSquareBoxGreenView(imageName: "1")
                        Text("Fruit and Vegie Peels")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 20)
                    }
                    
                    VStack{
                        SmallSquareBoxGreenView(imageName: "2")
                        Text("Used Tea Bags")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.trailing , 20)
                    }
                    VStack{
                        SmallSquareBoxGreenView(imageName: "3")
                        Text("Pet Poop")
                            .font(.system(size: 15))
                            .foregroundColor(.gray)
                            .padding(.leading , 20)
                    }
                }
            }
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .background {
                Color.black.opacity(1.0)
                    .ignoresSafeArea()
            }
    }
}

struct ImageAndScrollPageGreen: View {
    var centerImage: String
  
    var body: some View {
        VStack {
            
            // Image in the Center
            CenteredImageGreenView(imageName: centerImage)
                .frame(width: 200, height: 200)
           
            Text("GREEN BIN")
                .font(.largeTitle)
                .padding(.top , 110)
                .padding(.bottom, 30)
            //Spacer()
            // Horizontal Scroll View with Square Boxes
//            ScrollView(.horizontal, showsIndicators: false) {
//                HStack(spacing: 20) {
//                    ForEach(1..<4) { index in
//                        SmallSquareBoxGreenView(imageName: "\(index)")
//                    }
//                }
//                .padding()
//            }
            
        }
    }
}

struct CenteredImageGreenView: View {
    var imageName: String
    
    var body: some View {
        Image(imageName)
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 250)
    }
}

struct SmallSquareBoxGreenView: View {
    var imageName: String
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 150, height: 150)
                .cornerRadius(10)
        }
        .background(Color.black)
        .cornerRadius(10)
    }
}

